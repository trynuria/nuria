# Spider data attribution

The included six SQLite databases and selected question/reference records are subsets of Spider 1.0 by Tao Yu, Rui Zhang, Kai Yang, Michihiro Yasunaga and the Spider authors (EMNLP 2018). The official project distributes this data under CC BY-SA 4.0.

Project and attribution: https://yale-lily.github.io/spider
Paper: https://aclanthology.org/D18-1425/
License: https://creativecommons.org/licenses/by-sa/4.0/

Database bytes and selected raw records are unmodified. Subsetting, generated schema documentation, execution traces and replay metadata are identified separately. Adaptations of the dataset are offered under the same CC BY-SA 4.0 terms. Code retains the repository license.
