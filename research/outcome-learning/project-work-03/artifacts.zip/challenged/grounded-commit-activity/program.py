import json


def task_func(data=None):
    if data is None:
        with open('inputs/commits.json', 'r', encoding='utf-8') as source:
            data = json.load(source)

    seen = set()
    days = {}
    different_times = 0

    for commit in data['commits']:
        sha = commit['sha']
        if sha in seen:
            continue
        seen.add(sha)

        day = commit['committed_at'][:10]
        if day not in days:
            days[day] = {'day': day, 'commits': 0, 'merges': 0}
        days[day]['commits'] += 1
        if len(commit['parent_shas']) > 1:
            days[day]['merges'] += 1
        if commit['authored_at'] != commit['committed_at']:
            different_times += 1

    report = {
        'head': data['head'],
        'unique_commits': len(seen),
        'committer_days': [days[day] for day in sorted(days)],
        'different_author_and_committer_times': different_times,
        'evidence': 'captured_git_commit_metadata',
    }
    with open('report.json', 'w', encoding='utf-8') as destination:
        json.dump(report, destination, indent=2)
    return report
