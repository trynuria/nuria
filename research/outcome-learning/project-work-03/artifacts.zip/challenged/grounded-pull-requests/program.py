import json


def task_func(data=None):
    if data is None:
        with open('inputs/pulls.json', 'r', encoding='utf-8') as source:
            data = json.load(source)

    requests = data['pull_requests']
    report = {
        'total': len(requests),
        'merged': [],
        'open': [],
        'closed_unmerged': [],
        'open_drafts': [],
        'evidence': 'captured_public_pull_requests',
    }

    for request in requests:
        number = request['number']
        if request['merged_at'] is not None:
            report['merged'].append(number)
        elif request['state'] == 'open':
            report['open'].append(number)
        elif request['state'] == 'closed':
            report['closed_unmerged'].append(number)

        if request['state'] == 'open' and request['draft'] is True:
            report['open_drafts'].append(number)

    for key in ('merged', 'open', 'closed_unmerged', 'open_drafts'):
        report[key].sort()

    with open('report.json', 'w', encoding='utf-8') as destination:
        json.dump(report, destination, indent=2)

    return report
