import json
from collections import deque


def task_func(data=None):
    if data is None:
        with open('inputs/ancestry.json', 'r', encoding='utf-8') as source:
            data = json.load(source)

    commits = {commit['sha']: commit for commit in data['commits']}
    head = data['head']
    distances = {head: 0}
    pending = deque([head])
    unobserved = set()

    while pending:
        sha = pending.popleft()
        if sha not in commits:
            unobserved.add(sha)
            continue
        for parent in commits[sha]['parent_shas']:
            if parent not in distances:
                distances[parent] = distances[sha] + 1
                pending.append(parent)

    components = []
    for name, sha in sorted(data['reported_components'].items()):
        if sha is None:
            reachable = None
            hops = None
        elif sha in distances:
            reachable = True
            hops = distances[sha]
        else:
            reachable = None if unobserved else False
            hops = None
        components.append({
            'component': name,
            'reported_commit': sha,
            'reachable': reachable,
            'minimum_parent_hops': hops,
        })

    report = {
        'head': head,
        'graph_nodes': len(commits),
        'unobserved_parent_ids': sorted(unobserved),
        'components': components,
        'direct_service_health': 'unknown',
        'evidence': 'observed_git_ancestry_only',
    }
    with open('report.json', 'w', encoding='utf-8') as destination:
        json.dump(report, destination, indent=2)
    return report
