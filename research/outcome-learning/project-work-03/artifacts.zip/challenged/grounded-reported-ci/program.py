import json
from datetime import datetime


def task_func(data=None):
    if data is None:
        with open('inputs/checks.json', 'r', encoding='utf-8') as source:
            data = json.load(source)

    runs = data['workflow_runs']
    latest_by_sha = {}
    for run in runs:
        key = (
            datetime.fromisoformat(run['updated_at'].replace('Z', '+00:00')),
            int(run['id']),
        )
        sha = run['head_sha']
        previous = latest_by_sha.get(sha)
        if previous is None or key > previous[0]:
            latest_by_sha[sha] = (key, run)

    heads = {}
    for label, sha in data['heads'].items():
        observed = latest_by_sha.get(sha)
        run = observed[1] if observed is not None else None
        reported_ci = 'unknown'
        if run is not None and run.get('status') == 'completed':
            conclusion = run.get('conclusion')
            if conclusion == 'success':
                reported_ci = 'passed'
            elif conclusion in ('failure', 'timed_out', 'action_required'):
                reported_ci = 'failed'
        heads[label] = {
            'head': sha,
            'latest_observed_run_id': run['id'] if run is not None else None,
            'reported_ci': reported_ci,
        }

    report = {
        'heads': heads,
        'observed_runs': len(runs),
        'total_reported_runs': data['total_reported_runs'],
        'coverage': 'observed_runs_only',
        'direct_service_health': 'unknown',
    }
    with open('report.json', 'w', encoding='utf-8') as destination:
        json.dump(report, destination, indent=2)
    return report
