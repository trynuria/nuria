import json
from datetime import datetime


def task_func(data=None):
    if data is None:
        with open("inputs/checks.json", "r", encoding="utf-8") as handle:
            data = json.load(handle)

    runs = data["workflow_runs"]
    latest = {}
    latest_keys = {}
    for run in runs:
        sha = run["head_sha"]
        key = (datetime.fromisoformat(run["updated_at"]), int(run["id"]))
        if sha not in latest_keys or key > latest_keys[sha]:
            latest[sha] = run
            latest_keys[sha] = key

    heads = {}
    for label, sha in data["heads"].items():
        run = latest.get(sha)
        reported_ci = "unknown"
        if run is not None and run["status"] == "completed":
            conclusion = run.get("conclusion")
            if conclusion == "success":
                reported_ci = "passed"
            elif conclusion in ("failure", "timed_out", "action_required"):
                reported_ci = "failed"
        heads[label] = {
            "head": sha,
            "latest_observed_run_id": run["id"] if run is not None else None,
            "reported_ci": reported_ci,
        }

    report = {
        "heads": heads,
        "observed_runs": len(runs),
        "total_reported_runs": data["total_reported_runs"],
        "coverage": "observed_runs_only",
        "direct_service_health": "unknown",
    }
    with open("report.json", "w", encoding="utf-8") as handle:
        json.dump(report, handle)
    return report
