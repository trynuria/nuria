import json
from collections import deque


def task_func(data=None):
    if data is None:
        with open("inputs/ancestry.json", "r", encoding="utf-8") as handle:
            data = json.load(handle)

    graph = {commit["sha"]: commit["parent_shas"] for commit in data["commits"]}
    head = data["head"]
    distances = {head: 0}
    queue = deque([head])
    unobserved = set()

    while queue:
        sha = queue.popleft()
        if sha not in graph:
            unobserved.add(sha)
            continue
        for parent in graph[sha]:
            if parent not in distances:
                distances[parent] = distances[sha] + 1
                queue.append(parent)

    components = []
    for component, commit in sorted(data["reported_components"].items()):
        if commit is None:
            reachable = None
            hops = None
        elif commit in distances:
            reachable = True
            hops = distances[commit]
        else:
            reachable = None if unobserved else False
            hops = None
        components.append({
            "component": component,
            "reported_commit": commit,
            "reachable": reachable,
            "minimum_parent_hops": hops,
        })

    report = {
        "head": head,
        "graph_nodes": len(graph),
        "unobserved_parent_ids": sorted(unobserved),
        "components": components,
        "direct_service_health": "unknown",
        "evidence": "observed_git_ancestry_only",
    }
    with open("report.json", "w", encoding="utf-8") as handle:
        json.dump(report, handle)
    return report
