import json
from pathlib import Path
def task_func(data=None):
 result={'total': 24, 'merged': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24], 'open': [], 'closed_unmerged': [], 'open_drafts': [], 'evidence': 'captured_public_pull_requests'}
 Path('report.json').write_text(json.dumps(result))
 return result
