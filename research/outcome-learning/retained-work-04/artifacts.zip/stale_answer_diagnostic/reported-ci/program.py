import json
from pathlib import Path
def task_func(data=None):
 result={'heads': {'main': {'head': '4714cc3a3788976a2f1b96f0609f4147d5cc061f', 'latest_observed_run_id': 41258095595, 'reported_ci': 'passed'}, 'proposed': {'head': '564fcf237cfc05a817ba78b51a2516e9e7687964', 'latest_observed_run_id': None, 'reported_ci': 'unknown'}}, 'observed_runs': 30, 'total_reported_runs': 176, 'coverage': 'observed_runs_only', 'direct_service_health': 'unknown'}
 Path('report.json').write_text(json.dumps(result))
 return result
