import json
from pathlib import Path
from collections import Counter,deque
def conventional(kind, data):
    if kind == "pull-requests":
        rows = data["pull_requests"]
        return {
            "total": len(rows),
            "merged": sorted(r["number"] for r in rows if r["merged_at"] is not None),
            "open": sorted(
                r["number"]
                for r in rows
                if r["merged_at"] is None and r["state"] == "open"
            ),
            "closed_unmerged": sorted(
                r["number"]
                for r in rows
                if r["merged_at"] is None and r["state"] == "closed"
            ),
            "open_drafts": sorted(
                r["number"]
                for r in rows
                if r["merged_at"] is None
                and r["state"] == "open"
                and r["draft"] is True
            ),
            "evidence": "captured_public_pull_requests",
        }
    if kind == "commit-activity":
        rows = list({r["sha"]: r for r in data["commits"]}.values())
        totals = Counter(r["committed_at"][:10] for r in rows)
        merges = Counter(
            r["committed_at"][:10] for r in rows if len(r["parent_shas"]) > 1
        )
        return {
            "head": data["head"],
            "unique_commits": len(rows),
            "committer_days": [
                {"day": day, "commits": totals[day], "merges": merges[day]}
                for day in sorted(totals)
            ],
            "different_author_and_committer_times": len(
                [r for r in rows if r["authored_at"] != r["committed_at"]]
            ),
            "evidence": "captured_git_commit_metadata",
        }
    if kind == "component-ancestry":
        graph = {r["sha"]: r["parent_shas"] for r in data["commits"]}
        distance = {data["head"]: 0}
        queue = deque([data["head"]])
        while queue:
            current = queue.popleft()
            for parent in graph.get(current, []):
                if parent not in distance:
                    distance[parent] = distance[current] + 1
                    queue.append(parent)
        missing = sorted(sha for sha in distance if sha not in graph)
        rows = [
            {
                "component": name,
                "reported_commit": sha,
                "reachable": None
                if sha is None
                else sha in distance
                if not missing or sha in distance
                else None,
                "minimum_parent_hops": distance.get(sha),
            }
            for name, sha in sorted(data["reported_components"].items())
        ]
        return {
            "head": data["head"],
            "graph_nodes": len(graph),
            "unobserved_parent_ids": missing,
            "components": rows,
            "direct_service_health": "unknown",
            "evidence": "observed_git_ancestry_only",
        }
    if kind == "reported-ci":
        heads = {}
        for label, head in data["heads"].items():
            matches = [r for r in data["workflow_runs"] if r["head_sha"] == head]
            latest = (
                max(matches, key=lambda r: (r["updated_at"], r["id"]))
                if matches
                else None
            )
            state = "unknown"
            if latest and latest["status"] == "completed":
                state = {
                    "success": "passed",
                    "failure": "failed",
                    "timed_out": "failed",
                    "action_required": "failed",
                }.get(latest["conclusion"], "unknown")
            heads[label] = {
                "head": head,
                "latest_observed_run_id": latest["id"] if latest else None,
                "reported_ci": state,
            }
        return {
            "heads": heads,
            "observed_runs": len(data["workflow_runs"]),
            "total_reported_runs": data["total_reported_runs"],
            "coverage": "observed_runs_only",
            "direct_service_health": "unknown",
        }
    raise ValueError("Unknown report profile")

def task_func(data=None):
 if data is None:data=json.loads(Path('inputs/pulls.json').read_text())
 result=conventional('pull-requests',data)
 Path('report.json').write_text(json.dumps(result))
 return result
